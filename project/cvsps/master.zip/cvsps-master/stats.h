/*
 * Copyright 2001, 2002, 2003 David Mansfield and Cobite, Inc.
 * See COPYING file for license information 
 */

#ifndef STATS_H
#define STATS_H

void print_statistics(void * ps_tree);

#endif /* STATS_H */
